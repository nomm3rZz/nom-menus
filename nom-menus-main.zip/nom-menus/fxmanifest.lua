fx_version 'cerulean'
game 'gta5'

author 'nomm3rZz'
description 'Custom Restaurant Menu Script'
version '1.0.0'

client_scripts {
    'client.lua'
}

shared_scripts {
    'config.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}

files {
    'nui/nui.html',
    'nui/nui.js',
    'nui/styles.css',
    'images/*.png'
}

ui_page 'nui/nui.html'