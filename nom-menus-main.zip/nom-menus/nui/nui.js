window.addEventListener('message', function(event) {
    const data = event.data;

    if (data.type === "showImage") {
        const imageElement = document.getElementById('displayImage');
        imageElement.src = `../images/${data.image}`;
        const inputContainer = document.getElementById('inputContainer');
        const menuContainer = document.getElementById('menu-container');
        document.body.style.display = 'flex';
        inputContainer.style.display = 'none';
        menuContainer.style.display = 'flex';
    } else if (data.type === "showInput") {
        const inputContainer = document.getElementById('inputContainer');
        const menuContainer = document.getElementById('menu-container');
        document.body.style.display = 'flex';
        menuContainer.style.display = 'none';
        inputContainer.style.display = 'flex';
    }
});

document.getElementById('closeButton').addEventListener('click', function() {
    document.body.style.display = 'none';
    document.getElementById('inputContainer').style.display = 'none';
    document.getElementById('menu-container').style.display = 'none';
    fetch(`https://${GetParentResourceName()}/closeImage`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({})
    });
});

document.getElementById('submitButton').addEventListener('click', function() {
    const imageUrl = document.getElementById('imageUrl').value;
    fetch(`https://${GetParentResourceName()}/submitImage`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ imageUrl })
    }).then(() => {
        document.getElementById('inputContainer').style.display = 'none';
        document.getElementById('menu-container').style.display = 'none';
        document.body.style.display = 'none';
    });
});

document.getElementById('cancelButton').addEventListener('click', function() {
    document.getElementById('inputContainer').style.display = 'none';
    fetch(`https://${GetParentResourceName()}/cancelImage`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({})
    });
});