Config = {}

Config.Images = {
    -- UWU Cafe
    {coords = vector3(436.78, -973.41, 30.72), job = 'uwucafe', image = "UWUMenu.png"},
    {coords = vector3(-585.41, -1063.56, 22.34), job = 'uwucafe', image = "UWUMenu.png"},

    -- Burgershot
    {coords = vector3(-1188.82, -893.77, 13.80), job = 'burgershot', image = "BSMenu.png"},
    {coords = vector3(-1190.94, -895.18, 13.80), job = 'burgershot', image = "BSMenu.png"},

    -- Gelato Ice Cream
    --{coords = vector3(-511.13, -64.93, 40.84), job = 'gelato', image = "UWUMenu.png"},

    -- Bahama Mamas
    {coords = vector3(-1383.06, -595.52, 30.22), job = 'bahama', image = "BahamaMenu.png"},
    {coords = vector3(-1381.35, -598.24, 30.22), job = 'bahama', image = "BahamaMenu.png"},
    {coords = vector3(-1379.36, -601.16, 30.22), job = 'bahama', image = "BahamaMenu.png"},
}

Config.MenusJobs = {
    'uwucafe',
    'burgershot',
    'bahama'
}