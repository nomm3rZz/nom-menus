QBCore = exports['qb-core']:GetCoreObject()
local isImageVisible = false
local currentImage = nil
local isOwnerMode = false

RegisterNUICallback('closeImage', function(data, cb)
    SetNuiFocus(false, false)
    isImageVisible = false
    cb('ok')
end)

RegisterNUICallback('submitImage', function(data, cb)
    local imageUrl = data.imageUrl
    local p = promise.new()
    QBCore.Functions.TriggerCallback('nom-menus:submitImage', function(result)
        p:resolve(result)
    end, imageUrl)
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNUICallback('cancelImage', function(data, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
	for _, imageData in ipairs(Config.Images) do
		local playerPed = PlayerPedId()
        	local playerCoords = GetEntityCoords(playerPed)
		local distance = #(playerCoords - imageData.coords)

            if distance < 1.0 then
        	local playerJob = QBCore.Functions.GetPlayerData().job.name
        	local notified = false

                ShowHelpNotification("Press ~INPUT_CONTEXT~ to view the menu..")
                
                if IsControlJustReleased(0, 38) then -- E key
                    TriggerServerEvent("InteractSound_SV:PlayOnSource", "paperflip", 1.0)
                    currentImage = imageData.image
                    isImageVisible = true
                    SendNUIMessage({
                        type = "showImage",
                        image = currentImage
                    })
                    SetNuiFocus(true, true)
                elseif IsControlJustReleased(0, 182) then -- L key
                    isOwnerMode = not isOwnerMode
                    if isOwnerMode then
                        TriggerServerEvent("InteractSound_SV:PlayOnSource", "heartmonbeat", 1.0)
                        SendNUIMessage({
                            type = "showInput"
                        })
                        SetNuiFocus(true, true)
                    else
                        SetNuiFocus(false, false)
                    end
                end
            end
        end
    end
end)


function ShowHelpNotification(msg)
    AddTextEntry('showHelpNotification', msg)
    BeginTextCommandDisplayHelp('showHelpNotification')
    EndTextCommandDisplayHelp(0, false, true, -1)
end