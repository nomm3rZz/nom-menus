local QBCore = exports['qb-core']:GetCoreObject()

QBCore.Functions.CreateCallback('nom-menus:submitImage', function(source, cb, data)
    local player = QBCore.Functions.GetPlayer(source)
    local playerJob = player.PlayerData.job.name
    local imageUrl = data
    local isAuth = false
    --print(imageUrl)
    for i, job in ipairs(Config.MenusJobs) do
        if job == playerJob then
            isAuth = true
        end
    end
    if not isAuth then
        --print('fokkof')
        cb('notAuth') return
    end

    local menuExists = false
    --print('Getting Menu')
    local row = MySQL.single.await('SELECT `id`, `job`, `url` FROM `nom_menus` WHERE `job` = ? LIMIT 1', {
        playerJob
    })
     
    if row then
        menuExists = true
        --print("Menu Found")
    end
    
         if not menuExists then
        MySQL.insert('INSERT INTO `nom_menus` (job, url) VALUES (?, ?)', {
            playerJob, imageUrl
        }, function(id)
            --print(id)
        end)
    else
        MySQL.update('UPDATE nom_menus SET url = ? WHERE job = ?', {
            imageUrl, playerJob
        }, function(affectedRows)
            --print(affectedRows)
        end)
    end

    cb('ok')
end)

QBCore.Functions.CreateCallback('getMenus', function(source, cb, data)
    local player = QBCore.Functions.GetPlayer(source)
    local playerJob = player.PlayerData.job.name
    local imageUrl = data.imageUrl

    -- Check if the player is an employee
    for i, imageData in ipairs(Config.Images) do
        if imageData.job == playerJob then
            MySQL.query('SELECT `firstname`, `lastname` FROM `users` WHERE `identifier` = ?', {
                identifier
            }, function(response)
                if response then
                    for i = 1, #response do
                        local row = response[i]
                        --print(row.firstname, row.lastname)
                    end
                end
            end)
            Config.Images[i].image = imageUrl
            cb('ok')
            return
        end
    end

    cb('not_authorized')
end)